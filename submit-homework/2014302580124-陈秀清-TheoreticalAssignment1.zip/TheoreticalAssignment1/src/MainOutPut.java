import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import jxl.*;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class MainOutPut {
	public static void main(String[] args) {	
		
		File file=new File("MyGrade.xls");
		MainOutPut mygrade=new MainOutPut();
		mygrade.processScoreTable(file);
   }
	public void processScoreTable(File Input){
		jxl.Workbook readwb=null;
		String [][] cellData;
		float credit;
		int score;
		float totalcredit=0,GPA=0,AVERAGE=0;
		try{
			InputStream instream=new FileInputStream(Input);
			readwb = Workbook.getWorkbook(instream);
			Sheet readsheet=readwb.getSheet( 0);
			int rsColumns=readsheet.getColumns();
			int rsRows=readsheet.getRows();
			cellData=new String[rsRows][rsColumns];
			//��Ԫ������д��String���Ͷ�ά����
		for(int i=0;i<rsRows;i++){
			for(int j=0;j<rsColumns;j++){
				Cell cell=readsheet.getCell(j,i);
				cellData[i][j]=cell.getContents();
			}
		}
	    //����������
		sortscore(cellData);
		//�����Ȩƽ���֡��ۺϼ�ȨGPA
		for(int i=1;i<rsRows;i++){
			credit=Float.parseFloat(cellData[i][3]);
			score=Integer.parseInt(cellData[i][9]);
			totalcredit+=credit;
			AVERAGE+=score*credit;
			if(score<100&&score>=90) GPA+=4.0*credit;
			else if(score>=85)GPA+=3.7*credit;
			else if(score>=82)GPA+=3.3*credit;
			else if(score>=78)GPA+=3.0*credit;
			else if(score>=75)GPA+=2.7*credit;
			else if(score>=72)GPA+=2.3*credit;
			else if(score>=68)GPA+=2.0*credit;
			else if(score>=64)GPA+=1.5*credit;
			else if(score>=60)GPA+=1.0*credit;
			else GPA+=0;
		}
		GPA=GPA/totalcredit;
		AVERAGE=AVERAGE/totalcredit;
		//�����µ�excel����
	WritableWorkbook newwb=Workbook.createWorkbook(new File("MyGrade1.xls"));
	WritableSheet newws=newwb.createSheet("����", 0);
	for(int i=0;i<rsRows;i++){
		for(int j=0;j<rsColumns;j++){
			newws.addCell(new Label(j,i,cellData[i][j]));
		}
	}
	//���ø�ʽ
	newws.setColumnView(0, 20);
	newws.setColumnView(1, 25);
	newws.setColumnView(4, 20);
	newws.setColumnView(5, 20);
	//���GPA,AVERGAGE
	newws.addCell(new Label(0,27,"��Ȩƽ����"));
	newws.addCell(new Label(1,27,String.valueOf(AVERAGE)));
	newws.addCell(new Label(0,28,"�ۺϼ�ȨGPA"));
	newws.addCell(new Label(1,28,String.valueOf(GPA)));
	newwb.write();
	newwb.close();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			readwb.close();
		}	
	}
	//���ݷ����Ӹߵ�������
	public static void sortscore(String[][] s){
		int row=s.length;
		int column=s[0].length;
		String strtemp;
		for(int i=1;i<row-1;i++){
			for(int j=1;j<row-i;j++){
				if(Integer.parseInt(s[j][9])<Integer.parseInt(s[j+1][9])){
					for(int n=0;n<column;n++){
						strtemp=s[j+1][n];
						s[j+1][n]=s[j][n];
						s[j][n]=strtemp;
					}
				}
			}
			
		}
	}

}
