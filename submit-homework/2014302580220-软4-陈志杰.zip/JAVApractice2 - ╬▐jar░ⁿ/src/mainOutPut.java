import java.io.*;


import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;




public class mainOutPut 
{


	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		mainOutPut a = new mainOutPut();
		File f = new File("D:/eclipse/workplace/JAVApractice2/IMG.html");
		a.processScoreTable(f);
	}
	
	
	//��ȡhtml�ļ������Դ���
	public void processScoreTable(File input)  throws IOException   
	{
		//��HTML�еĳɼ�Ԫ�ػ�ȡ�������뵽excel�ļ���
			Document doc = Jsoup.parse(input,"gb2312","http://www.baidu.com/");
			Elements trs = doc.select("tr");
			String [][] data = new String[trs.size()-1][10];             //���ݴ���һ����ά������
			System.out.println(trs.size());
			System.out.println(trs.get(42).select("td").get(1));
			System.out.println(trs.get(1).select("td").get(1));
			for(int i = 0 ;i<(trs.size()-1);i++){                        //�������е�tdԪ��
				Elements tds = trs.get(i+1).select("td");
				for(int j = 0;j<9;j++){
					data[i][j] = tds.get(j).text().toString();
				}
				if(tds.get(9).text().toString().trim().isEmpty()){
					data[i][9] = "0";
				}else{
					data[i][9] = tds.get(9).text().toString();
				}
			}
			


		
		
		//����Excel�ļ�
/*		POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(input));
		HSSFWorkbook wb = new HSSFWorkbook(fs);
		HSSFSheet sheet = wb.getSheetAt(0);    //��õ�һ������
		Subject []subject = new Subject[sheet.getLastRowNum()];               //����һ���Ϳ�Ŀ��Ŀһ���Ĵ�С������
		for(int i=sheet.getFirstRowNum();i<sheet.getLastRowNum();i++){           //�������������һ���������������Ԫ����
			HSSFRow row = sheet.getRow(i);
			if(row!=null){
				Subject sub = new Subject();
				sub.SetID(row.getCell(0).toString());
				sub.Setname(row.getCell(1).toString());
				sub.Settype(row.getCell(2).toString());
				sub.Setcredit(Double.valueOf((row.getCell(3).toString())));
				sub.Setteacher(row.getCell(4).toString());
				sub.Setschool(row.getCell(5).toString());
				sub.Setyear(row.getCell(7).toString());
				sub.Setterm(row.getCell(8).toString());
				sub.Setscore(Double.valueOf(row.getCell(9).toString()));
				subject[i] = sub;
			}
		}           */

			
		//���շ����ߵ�����
		SortByScore(data);
		
		//�����Ȩƽ���֡��ۺϼ�Ȩƽ����
		double average = GetAverage(data);
		double comAverage = GetComAverage(data);
		
		
		//���������vectorд���½���excelһ���µ�sheet��
		
		try{
			FileOutputStream fout = new FileOutputStream("score.xls");
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet s = workbook.createSheet("sheet2");
			for(int i =0;i<data.length;i++){                      //��xls�ļ�����һ��sheet�ｫ�ź�������ݴ����ȥ
				HSSFRow row = s.createRow(i);
                row.createCell(0).setCellValue(data[i][0]);
                row.createCell(1).setCellValue(data[i][1]);
                row.createCell(2).setCellValue(data[i][2]);
                row.createCell(3).setCellValue(data[i][3]);
                row.createCell(4).setCellValue(data[i][4]);
                row.createCell(5).setCellValue(data[i][5]);
                row.createCell(6).setCellValue("��ͨ");
                row.createCell(7).setCellValue(data[i][7]);
                row.createCell(8).setCellValue(data[i][8]);
                row.createCell(9).setCellValue(data[i][9]);
			 }
			 HSSFRow row = s.createRow(data.length);
			 row.createCell(6).setCellValue("��Ȩƽ���֣�"+ average);
			 row.createCell(9).setCellValue("�ۺ�ƽ���֣�"+ comAverage);
			 
			//����
			 workbook.write(fout);
             fout.flush();
             //�����ر�
             fout.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	//����ÿһ��Ŀ����
	public double CreditSubject(String s){
		double a = 0;
		if(Double.valueOf(s.trim()) >= 90) a =4.0;
		else if(Double.valueOf(s.trim()) >= 85 && Double.valueOf(s.trim()) <90 ) a =3.7;
		else if(Double.valueOf(s.trim()) >= 82 && Double.valueOf(s.trim()) <85 ) a =3.3;
		else if(Double.valueOf(s.trim()) >= 78 && Double.valueOf(s.trim()) <82 ) a =3.0;
		else if(Double.valueOf(s.trim()) >= 75 && Double.valueOf(s.trim()) <78 ) a =2.7;
		else if(Double.valueOf(s.trim()) >= 72 && Double.valueOf(s.trim()) <75 ) a =2.3;
		else if(Double.valueOf(s.trim()) >= 68 && Double.valueOf(s.trim()) <72 ) a =2.0;
		else if(Double.valueOf(s.trim()) >= 64 && Double.valueOf(s.trim()) <68 ) a =1.5;
		else if(Double.valueOf(s.trim()) >= 60 && Double.valueOf(s.trim()) <64 ) a =1.0;
		else if(Double.valueOf(s.trim()) < 60 ) a =0.0;
		return a;
	}
	
	//��������Ӵ�С����
	public void SortByScore(String[][] sub1){
		String sj = new String();
		for(int i =0;i<(sub1.length-1);i++){   
            for(int j =i+1;j<sub1.length;j++){
            	System.out.println(sub1[i][9]);
            	System.out.println(sub1[j][9]);
				if(Double.valueOf(sub1[i][9].trim()) < Double.valueOf(sub1[j][9].trim())){
					sj =  sub1[i][9];
					sub1[i][9] =  sub1[j][9];
					sub1[j][9] =  sj;
				}
			}
			
		}
	}
	
	
	//�����Ȩƽ����
	public double GetAverage(String[][] subject){
		double average = 0;    
		double allCreditScore = 0;
		double allCredit = 0;
		for(int i = 0;i<subject.length;i++){
			if(Double.valueOf(subject[i][9].trim()) != 0){
				allCredit = allCredit + Double.valueOf(subject[i][3].trim());
			}
		}
		for(int i =0;i<subject.length;i++){
			if(Double.valueOf(subject[i][9].trim()) != 0){
				allCreditScore = allCreditScore + Double.valueOf(subject[i][9].trim())*Double.valueOf(subject[i][3].trim());
			}
		}
		return allCreditScore/allCredit;
	}
	
	//�����ۺϼ�Ȩƽ����
	public double GetComAverage(String[][] subject){
		double comAverage = 0;
		double allCredit = 0 ;
	    double allSubjectCredit = 0;
	    for(int i = 0;i<subject.length;i++){
	    	if(Double.valueOf(subject[i][9].trim()) != 0){
	    		allCredit = allCredit + Double.valueOf(subject[i][3].trim());
	    	}
	    }
	    for(int i = 0;i<subject.length;i++){
	    	if(Double.valueOf(subject[i][9].trim()) != 0){
	    		allSubjectCredit = allSubjectCredit + Double.valueOf(subject[i][3].trim()) * CreditSubject(subject[i][9]);
	    	}
	    }
		return allSubjectCredit/allCredit;
	}

}
