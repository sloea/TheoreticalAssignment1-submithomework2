package score;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;

 
public class Text {
	public static String readTxtFile(String filePath) throws ParseException, IOException{
		
		
		InputStreamReader reader = new InputStreamReader(new FileInputStream(filePath),"utf-16");   //保存原始数据的txt文档，并以utf－16编码
		String text ="";
		int b;
		float total_sorce=0;
		float total_point=0;
		float gpa=0;
		while((b=reader.read())!=-1){//检查是否读取完成		               
			                   char c = (char) b;  
			                    text+=String.valueOf(c);  
			           }
		//System.out.println(text); //text保存了表单内所有信息
		
		String[] strs = text.replaceAll("\r", "").split("\n");
		
		
		List<String> list = new LinkedList<String>();//建立链表
		List<String> sortList = new LinkedList<String>();
		for(int i=0;i<strs.length;i++){
			list.add(strs[i]);
		}
		
		
		for(int k=0;k<list.size();k++){
			String s1 = list.get(k);//s1字符串从表单首部开始依次取数据
			String[] personInfo1 = s1.split("\\s+");//以空格为截断符号进行截取
			
			for(int j=list.size()-1;j>=0;j--){//嵌套循环，从表单尾部开始取数据保存在s2中，这里要注意txt文件中最后行不能是回车引起的空白行
				int scorce1 = Integer.valueOf(personInfo1[9]);//personiInfo函数返回字符数组，故在这里取第10个数据（成绩）
				
				String s2 = list.get(j);
				String[] personInfo2 = s2.split("\\s+");
				int scorce2 = Integer.valueOf(personInfo2[9]);
				
				if(scorce1<scorce2){//可以通过更改这里的函数参数来实现不同功能
					break;
				}else{
					if(j==0){
						sortList.add(s1);
						list.remove(s1);
						k=-1;
					}
				}
				
				float point = Float.parseFloat(personInfo1[3]);//get the point
				
				total_sorce += point*scorce1;
				total_point += point;
				
				if(scorce1>=90){
					gpa+=4.0*point;
				}else if(scorce1>=85){
					gpa+=3.7*point;
				}else if(scorce1>=82){
					gpa+=3.3*point;
				}else if(scorce1>=78){
					gpa+=3.0*point;
				}else if(scorce1>=75){
					gpa+=2.7*point;
				}else if(scorce1>=72){
					gpa+=2.3*point;
				}else if(scorce1>=68){
					gpa+=2.0*point;
				}else if(scorce1>=64){
					gpa+=1.5*point;
				}else if(scorce1>=60){
					gpa+=1.0*point;
				}else{
					gpa+=0.0*point;
				}
				
				
			}
		}
		
		float average = 0;
		average = (total_sorce)/(total_point);
		gpa = gpa/total_point;
		//System.out.println(gpa);
		
		
		String result = "按照成绩排序";
		for(String str:sortList){//在每一行结尾加上回车
			result += "\n" + str;
		}
		result += "\n"+"average_grade: "+average+"\n"+"gpa: "+gpa;
		return result;
	}
	
	
	public static void mainOutPut(String input, String result) throws ParseException, IOException{
		
		OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(input));
		writer.write(result, 0, result.length());//output
		writer.close();
		
	}


	
               
                    
        
     
    public static void main(String argv[]) throws ParseException, IOException{
        String inPut_filePath = "/Users/Oscar/scorce.txt";
        String result = readTxtFile(inPut_filePath);
        System.out.println(result);
        String outPut_filePath = "/Users/Oscar/result.txt";
        mainOutPut(outPut_filePath,result);
    }
     
     
 
}