import java.io.File;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


public class MainOutPut {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		    int i;
		    int n;
		    double[] grade,point,gpa;
		    String[] he,le,tp,pt,te,ad,term,gr,gp;
		    he=new String[22];
		    le=new String[22];
		    tp=new String[22];
		    pt=new String[22];
		    te=new String[22];
		    ad=new String[22];
		    term=new String[22];
		    gr=new String[22];
		    gp=new String[22];
		    grade=new double[22];
		    point=new double[22];
		    gpa=new double[22];
	        Sheet sheet;
	        Workbook book;
	        Cell cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8;
	        try { 
	            //t.xlsΪҪ��ȡ��excel�ļ���
	            book= Workbook.getWorkbook(new File("grade.xls")); 
	             
	            //��õ�һ������������(excel��sheet�ı�Ŵ�0��ʼ,0,1,2,3,....)
	            sheet=book.getSheet(0); 
	            //��ȡ���Ͻǵĵ�Ԫ��
	            cell1=sheet.getCell(0,0); 	             
	            i=1;
	            while(i<=21)
	            {
	                //��ȡÿһ�еĵ�Ԫ�� 
	                cell1=sheet.getCell(0,i);//���У��У�
	                cell2=sheet.getCell(1,i);
	                cell3=sheet.getCell(2,i);
	                cell4=sheet.getCell(3,i);
	                cell5=sheet.getCell(4,i);
	                cell6=sheet.getCell(5,i);
	                cell7=sheet.getCell(8,i);
	                cell8=sheet.getCell(9,i);
	                he[i]=cell1.getContents();
	                le[i]=cell2.getContents();
	                tp[i]=cell3.getContents();
	                pt[i]=cell4.getContents();
	                te[i]=cell5.getContents();
	                ad[i]=cell6.getContents();
	                term[i]=cell7.getContents();
	                gr[i]=cell8.getContents();
	                grade[i]=Double.parseDouble(gr[i]);
	        	    point[i]=Double.parseDouble(pt[i]);
	                i++;
	                
	            } 
	            double sumofgrade=0;
	            double avegrade=0;
	            double sumofpoint=0;
	            double sumofgpa=0;
	            double avegpa=0;
	            
	            n=1;
	            while(n<=21){
	            	 if (grade[n]>=90){gpa[n]=4.0;}
	            	 else if(grade[n]>=85){gpa[n]=3.7;}
	            	 else if(grade[n]>=82){gpa[n]=3.3;}
	            	 else if(grade[n]>=78){gpa[n]=3.0;}
	            	 else if(grade[n]>=75){gpa[n]=2.7;}
	            	 else if(grade[n]>=72){gpa[n]=2.3;}
	            	 else if(grade[n]>=68){gpa[n]=2.0;}
	            	 else if(grade[n]>=64){gpa[n]=1.5;}
	            	 else if(grade[n]>=60){gpa[n]=1.0;}
	            	 else{gpa[n]=0;}
	            	 sumofpoint+=point[n];
	            	 sumofgrade+=grade[n]*point[n];
	            	 sumofgpa+=gpa[n]*point[n];
	            	 gp[n]=Double.toString(gpa[n]);
	            	 n++;
	             }
	        
	            String a,b;
	            avegrade=sumofgrade/sumofpoint;
	            avegpa=sumofgpa/sumofpoint;
	            a=Double.toString(avegrade);
	            b=Double.toString(avegpa);
	            WritableWorkbook workbook = Workbook.createWorkbook(new File("gradedeal.xls"));
	            WritableSheet sheet1 = workbook.createSheet("grade", 0);
	          //��������һ�еĽ���
	            Label label0=new Label(0,0,"��ͷ��");
	            Label label1=new Label(1,0,"�γ�����");
	            Label label2=new Label(2,0,"�γ�����");
	            Label label3=new Label(3,0,"ѧ��");
	            Label label4=new Label(4,0,"��ʦ");
	            Label label5=new Label(5,0,"�ڿ�ѧԺ");
	            Label label6=new Label(6,0,"ѧϰ����");
	            Label label7=new Label(7,0,"ѧ��");
	            Label label8=new Label(8,0,"ѧ��");
	            Label label9=new Label(9,0,"�ɼ�");
	            Label label10=new Label(10,0,"GPA");
	           //������õı��񲿷����ӵ�������ȥ
	            sheet1.addCell(label0);
	            sheet1.addCell(label1);
	            sheet1.addCell(label2);
	            sheet1.addCell(label3);
	            sheet1.addCell(label4);
	            sheet1.addCell(label5);
	            sheet1.addCell(label6);
	            sheet1.addCell(label7);
	            sheet1.addCell(label8);
	            sheet1.addCell(label9);
	            sheet1.addCell(label10);
	            System.out.println("���1");
	           i=1;
	           int w=1;
	           int counter=1;
	           while(i<=21){
	           while(w<=21){
	        	   if(grade[i]==grade[w]){
	        		   if(i>w)
	        			   counter++;
	        	   };
	        	   if(grade[i]<grade[w])
	        	        counter++;
	        	   System.out.println("���"+grade[w]);
	        	   w++;
	           }
	           Label labe0=new Label(0,counter,he[i]);
	           sheet1.addCell(labe0);
	           Label labe1=new Label(1,counter,le[i]);
	           sheet1.addCell(labe1);
	           Label labe2=new Label(2,counter,tp[i]);
	           sheet1.addCell(labe2);
	           Label labe3=new Label(3,counter,pt[i]);
	           sheet1.addCell(labe3);
	           Label labe4=new Label(4,counter,te[i]);
	           sheet1.addCell(labe4);
	           Label labe5=new Label(5,counter,ad[i]);
	           sheet1.addCell(labe5);
	           Label labe6=new Label(6,counter,"��ͨ");
	           sheet1.addCell(labe6);
	           Label labe7=new Label(7,counter,"2014");
	           sheet1.addCell(labe7);
	           Label labe8=new Label(8,counter,term[i]);
	           sheet1.addCell(labe8);
	           Label labe9=new Label(9,counter,gr[i]);
	           sheet1.addCell(labe9);
	           Label labe10=new Label(10,counter,gp[i]);
	           sheet1.addCell(labe10);
	           labe0=null;
	           labe1=null;
	           labe2=null;
	           labe3=null;
	           labe4=null;
	           labe5=null;
	           labe6=null;
	           labe7=null;
	           labe8=null;
	           labe9=null;
	           labe10=null;
	           System.out.println(i);
	           counter=1;
	           w=1;
	           i++;
	           }
	           Label lab1=new Label(9,22,a);
	           sheet1.addCell(lab1);
	           Label lab2=new Label(10,22,b);
	           sheet1.addCell(lab2);
	           System.out.println("�������");
	           workbook.write();
	           workbook.close();
	        }
	        catch(Exception e)  { } 


	}

}
