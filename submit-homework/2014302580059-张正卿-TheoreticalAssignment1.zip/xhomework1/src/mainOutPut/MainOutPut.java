/* 2014302580059-������-TheoreticalAssignment1 */



/* ʮ�ֱ�Ǹ����Ϊû�мƻ��ö��Ѵ���д�÷ǳ����Ҷ�����
 * Ч�ʷǳ��ͣ�����ΪDL�ڼ�
 * û��ʱ���ٴ�ͷ�޸ģ�ֻ���Ͻ�
 * Ϊ����ɵ����Ż������̼���
 *  */
package mainOutPut;

import java.io.File;
import jxl.*;
import jxl.write.*;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;


public class MainOutPut {
	
	public static void main(String[] args) throws Exception{
		MainOutPut output = new MainOutPut();
		output.processScoreTable(new File("Grade.xls"));

	}
	
	public void processScoreTable(File input) throws Exception{
		
		//����
		Workbook rebook=Workbook.getWorkbook(input);
		Sheet resheet=rebook.getSheet(0);
		Cell cell;
		
		//��������
		 
		String id[] = new String[23]; 
		String name[] = new String[23];
		String type[] = new String[23];
		String credit[] = new String[23];
		double ncredit[] = new double[23];
		String teacher[] = new String[23];
		String department[] = new String[23];
		String studyType[] = new String[23];
		String year[] = new String[23];
		String term[] = new String[23];
		String score[] = new String[23];
		double nscore[] = new double[23];
		
		//��������
		for(int j=1;j<24;j++){
			cell=resheet.getCell(0,j);
			id[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(1,j);
			name[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(2,j);
			type[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(4,j);
			teacher[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(5,j);
			department[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(6,j);
			studyType[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(7,j);
			year[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(8,j);
			term[j-1]=cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(3,j);
			credit[j-1]= cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(3,j);
			ncredit[j-1]= Double.parseDouble(cell.getContents());
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(9,j);
			score[j-1]= cell.getContents();
		}
		for(int j=1;j<24;j++){
			cell=resheet.getCell(9,j);
			nscore[j-1]= Double.parseDouble(cell.getContents());
		}
		
		
		//��ؼ���
		
		double average=0.0;
		double gpa=0.0;
		double atemp=0.0;
		
		for (int i = 0; i<23;i++){
			average += ncredit[i] * nscore[i];
			atemp += ncredit[i];
		}
		for (int i =0; i<23; i++){
			if(nscore[i]<60){
				gpa += 0*ncredit[i];
			}else if(nscore[i]<64){
				gpa +=1.0*ncredit[i];
			}else if(nscore[i]<68){
				gpa +=1.5*ncredit[i];
			}else if(nscore[i]<72){
				gpa +=2.0*ncredit[i];
			}else if(nscore[i]<75){
				gpa +=2.3*ncredit[i];
			}else if(nscore[i]<78){
				gpa +=2.7*ncredit[i];
			}else if(nscore[i]<82){
				gpa +=3.0*ncredit[i];
			}else if(nscore[i]<85){
				gpa +=3.3*ncredit[i];
			}else if(nscore[i]<90){
				gpa +=3.7*ncredit[i];
			}else if(nscore[i]<101){
				gpa +=4.0*ncredit[i];
			}
		}
		
		
		//����
		
		for(int i = score.length - 1;i>0;--i){
		    String temp ;
		    double ntemp;

			for(int j = 0;j < i;++j){

				if(nscore[j+1] < nscore[j]){
					temp = score[j];
					score[j] = score[j+1];
					score[j+1] = temp;
					ntemp = nscore[j];
					nscore[j] = nscore[j+1];
					nscore[j+1] = ntemp;
					temp = name[j];
					name[j] = name[j+1];
					name[j+1] = temp;
					temp = id[j];
					id[j] = id[j+1];
					id[j+1] = temp;
					temp = type[j];
					type[j] = type[j+1];
					type[j+1] = temp;
					temp = credit[j];
					credit[j] = credit[j+1];
					credit[j+1] = temp;
					temp = teacher[j];
					teacher[j] = teacher[j+1];
					teacher[j+1] = temp;
					temp = department[j];
					department[j] = department[j+1];
					department[j+1] = temp;
					temp = studyType[j];
					studyType[j] = studyType[j+1];
					studyType[j+1] = temp;
					temp = year[j];
					year[j] = year[j+1];
					year[j+1] = temp;
					temp = term[j];
					term[j] = term[j+1];
					term[j+1] = temp;
				}
			}
		}
		
		//���
		
		WritableWorkbook book=Workbook.createWorkbook(new File("newGrade.xls"));
				WritableSheet sheet=book.createSheet("sheet1",0);
				Label label;
				jxl.write.Number number;
				
				for(int j=1;j<24;j++){
				label=new Label(0,24-j,id[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(1,24-j,name[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(2,24-j,type[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(3,24-j,credit[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(4,24-j,teacher[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(5,24-j,department[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(6,24-j,studyType[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(7,24-j,year[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(8,24-j,term[j-1]);
				sheet.addCell(label);
				}
				for(int j=1;j<24;j++){
				label=new Label(9,24-j,score[j-1]);
				sheet.addCell(label);
				}

				label=new Label(0,25,"��Ȩƽ����");
				sheet.addCell(label);
				number = new jxl.write.Number(1,25,average/atemp);
				sheet.addCell(number);
				label=new Label(0,26,"��Ȩ����");
				sheet.addCell(label);
				number = new jxl.write.Number(1,26,gpa/atemp);
				sheet.addCell(number);
				//д�����ݲ��ر��ļ�
				book.write();
				book.close();
	}

}