package com.score;

import java.awt.FlowLayout;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;


public class MainGUI {
 
	public static void main(String[] args) {
		
		Score myScore=new Score();
		File myFile=new File("test.html");
		myScore.processScoreTable(myFile);
		MainGUI myGui=new MainGUI();
		myGui.go();

	}
	public void go(){
		JFrame frame=new JFrame();

        String[] columnNames =  
        { "��ͷ��", "�γ�����", "�γ�����", "ѧ��", "��ʦ", "�ڿ�ѧԺ" ,"ѧϰ����","ѧ��","ѧ��","�ɼ�"};  
  
        Object[][] obj = new Object[25][10];  
        for (int i = 0; i < 25; i++)  
        {  
            for (int j = 0; j < 10; j++)  
            {  
            	obj[i][j] = Score.table[i][j]; 
                }  
            }  
         
        JTable scoretable = new JTable(obj, columnNames);  
        TableColumn column = null;  
        int colunms = scoretable.getColumnCount();
        for(int i = 0; i < colunms; i++)  
        {  
            column = scoretable.getColumnModel().getColumn(i);  
       
            column.setPreferredWidth(100);  
        }  
       
        scoretable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);  
          
       
        JScrollPane scroll = new JScrollPane(scoretable);  
        scroll.setSize(300, 200); 
        
        
        frame.setLayout(new FlowLayout(FlowLayout.LEFT));    
        JLabel label1 = new JLabel("��Ȩƽ���֣�"+Score.waverage , JLabel.LEFT);  
        JLabel label2 = new JLabel("GPA��" +Score.gpa, JLabel.LEFT);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        frame.setLayout(new FlowLayout(FlowLayout.LEFT));
        frame.add(scroll);  
        frame.getContentPane().add(label1);  
        frame.getContentPane().add(label2); 
        
        frame.pack();  
        frame.setVisible(true);  
       
        
	}
}

