package com.score;

import java.io.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Score {

	public static String[][] table = new String[25][11];
	public static double gpa;
	public static double waverage;
	public void processScoreTable(File input){
		try{
			
			Document doc = Jsoup.parse(input,"gb2312");
			Elements links = doc.getElementsByTag("td");
			File f=new File("out.xls");
		    f.createNewFile();
		    FileOutputStream fileOutputStream = new FileOutputStream(f);
		    PrintStream printStream = new PrintStream(fileOutputStream);
		    System.setOut(printStream);
		    
			int m=0;
			int n=0;
			for (Element link : links) {
				String linkText = link.text();
			    table[m][n]=linkText;
			    n++;
			    if(n>10){
			    m++;
			    n=0;}
			    if(table[table.length-1][9]!=null)
			    	break;
			    }
			for(int k=1;k<table.length;k++)
			{
				for(int i=k;i>0 ;i--)
				{
				double a=Double.parseDouble(table[i][9]);
				double b=Double.parseDouble(table[i-1][9]);
					if(a>b){
						String[]temp=table[i];
						table[i]=table[i-1];
						table[i-1]=temp;
					}
				}
			}

			for(int i = 0; i < table.length ; i++)
			{
			    for(int j = 0 ; j < table[i].length ; j++)
			        System.out.print(table[i][j]+"\t");
			    System.out.println();
			}
			double sumgrade=0;
			double credit=0;
			for(int i=0;i<table.length ;i++)
			{
				double weightgrade=Double.parseDouble(table[i][3])*Double.parseDouble(table[i][9]);
				credit=credit+Double.parseDouble(table[i][3]);
				sumgrade=sumgrade + weightgrade;
			}
		    waverage=sumgrade/credit;
			System.out.println("Weightedaverage:"+waverage);
			double sumgpa=0;
			double g=0;
			for(int i=0; i < table.length;i++){
				double s=Double.parseDouble(table[i][9]);
				if (s >= 90)
					g = 4.0;
				else if (85 <= s )
					g = 3.7;
				else if (82 <= s )
					g = 3.3;
				else if (78 <= s )
					g = 3.0;
				else if (75 <= s )
					g = 2.7;
				else if (72 <= s )
					g= 2.3;
				else if (68 <= s)
					g= 2.0;
				else if (64 <= s )
					g = 1.5;
				else if (60 <= s )
					g = 1.0;
				else if (s <= 59)
					g = 0.0;
				double weightgpa=g*Double.parseDouble(table[i][3]);
				sumgpa=sumgpa+weightgpa;
			}
			gpa=sumgpa/credit;
			System.out.println("GPA:"+gpa);
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
		
	}
