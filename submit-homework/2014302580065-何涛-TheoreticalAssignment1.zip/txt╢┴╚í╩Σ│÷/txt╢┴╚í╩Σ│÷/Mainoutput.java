package txt��ȡ���;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;
/**
 * ������������ϴ���-_-
	 * @throws ParseException 
	 * @throws IOException 
	 */

public class Mainoutput {
	
	public static void main(String[] args) throws  IOException {
		File file = new File("gradelist.txt");
		Mainoutput mop = new Mainoutput();
		mop.processScoreTable(file);
	}
	public void processScoreTable(File input) throws IOException{
		File file = new File("C:\\gradelist.txt");
        if(!file.exists())
            throw new RuntimeException("�ļ������ڣ�");
        BufferedReader br = new BufferedReader(new FileReader(file));
        BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\newgradelist.txt"));
        String str = null;
        List<String> list = new ArrayList<String>();
        while((str=br.readLine())!=null){
            list.add(str);
        }
        String[] arr = new String[list.size()];
        TreeSet<course> tr = new TreeSet<course>();
        arr = list.toArray(arr);
        for(int i = 0; i < arr.length; i++){
            String[] line = arr[i].split(" +");
            for(int j = 0; j < line.length; j++){
                if(i == 0)
                    bw.write(line[j]+"\t");
                else{
                    tr.add(new course(Integer.parseInt(line[0]),
                            line[1],Integer.parseInt(line[2]),
                            Integer.parseInt(line[3]),Integer.parseInt(line[4]),
                            (Integer.parseInt(line[2])+Integer.parseInt(line[3])+Integer.parseInt(line[4])/3),
                            (Integer.parseInt(line[2])+Integer.parseInt(line[3])+Integer.parseInt(line[4]))));
                }
            }
            System.out.println();
        }
        bw.write("\r\n");
        int num = 1;
        double averagegrades = getAveragegrades(null);
		double averagegpa = getAverageGPA(null);
        for(Iterator<course> it = tr.iterator(); it.hasNext();){
            bw.write(it.next().toString());
            bw.write("\t"+(num++)+"\r\n");
            bw.write("��Ȩƽ���֣� "+averagegrades+"\t\t"+"�ۺϼ�ȨGPA: "+averagegpa);
			bw.close();
        }
        br.close();
        bw.close();
    }

	
		
		//File sortedfile = new File("C:/newgradelist.txt");
		//OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(sortedfile));
		//writer.write(a, 0, a.length());
		//writer.close();
  

	
	private double getAveragegrades(ArrayList<course> al) {
		// TODO Auto-generated method stub
		double averagescore;
		double sumcredit=0;
		double sumscore=0;
		for(course i:al){
			double credit = i.getCredit();
			double score = i.getGrade();
			sumcredit = sumcredit + credit;
			sumscore = sumscore + score*credit;
		}
		averagescore = sumscore / sumcredit;
		return averagescore;
	}
	private double getAverageGPA(ArrayList<course> al) {
		// TODO Auto-generated method stub
		double sumgpa = 0;
		double averagegpa;
		double sumcredit=0;
		
		for(course i:al)
		{
			double gpa = 0;
			double credit = i.getCredit();
			double grade = i.getGrade();
			sumcredit = sumcredit + credit;
			
			if(grade>=90&&grade<=100)
			{
				gpa = 4.0;
			}
			if(grade>=85&&grade<=89)
			{
				gpa = 3.7;
			}
			if(grade>=82&&grade<=84)
			{
				gpa = 3.3;
			}
			if(grade>=78&&grade<=81)
			{
				gpa = 3.0;
			}
			if(grade>=75&&grade<=77)
			{
				gpa = 2.7;
			}
			if(grade>=72&&grade<=74)
			{
				gpa = 2.3;
			}
			if(grade>=68&&grade<=71)
			{
				gpa = 2.0;
			}
			if(grade>=64&&grade<=67)
			{
				gpa = 1.5;
			}
			if(grade>=60&&grade<=63)
			{
				gpa = 1.0;
			}
			if(grade<60)
			{
				gpa = 0;
			}
			sumgpa = sumgpa + gpa*credit;
		}
		averagegpa = sumgpa / sumcredit; 
		return averagegpa;
	}
}
class course{
		String cNumber;
		String cName;
		String cType;
		double credit;
		String teacher;
		String school;
		String learntype;
		String year;
		String term;
		int grade;
		
		public double getGrade()
		{
			return grade;
		}
		public double getCredit()
		{
			return credit;
		}
		
		public course(
		String m_cNumber,
		String m_cName,
		String m_cType,
		double m_credit,
		String m_teacher,
		String m_school,
		String m_learntype,
		String m_year,
		String m_term,
		int m_grade){
			this.cNumber = m_cNumber;
			this.cName = m_cName;
			this.cType = m_cType;
			this.credit = m_credit;
			this.teacher = m_teacher;
			this.school = m_school;
			this.learntype = m_learntype;
			this.year = m_year;
			this.term = m_term;
			this.grade = m_grade;
		}
		public course(int parseInt, String string, int parseInt2, int parseInt3, int parseInt4, int i, int j) {
			// TODO Auto-generated constructor stub
		}
		public int compareTo(course crs) {
	        int num = Integer.valueOf(crs.grade).compareTo(Integer.valueOf(this.grade));
	        if(num == 0)
	            return Integer.valueOf(crs.cNumber).compareTo(Integer.valueOf(this.cNumber));
	        return num;
	    }
	    public String toString(){
	        return cNumber+"\t"+cName+"\t"+cType+"\t"+credit+"\t"+teacher+"\t"+school+"\t"+learntype+"\t"+year+"\t"+term+"\t"+grade;
	    }
}


