package ��ҵ;
import java.io.File;
public class A 
{
public static void main(String[]args){
	String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2028%202015%2022:08:22%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
	HttpRequest request = HttpRequest.get(url);
	request.header("Cookie","JSESSIONID=502E59154B370AC70669E8B76878DB24.tomcat2");
	String path=("grade.html");
	request.receive(new File(path));
}
}
