package myGrades;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class MainGUI {
    public static void main(String[]args)
    {
    	EventQueue.invokeLater(new Runnable()
    	    {
    		    public void run()
    		    {
    			    Button frame=new Button();
    			    frame.setTitle("我的成绩单");
    			    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    			    frame.setVisible(true); 
    			    frame.setSize(400, 300);
    			    
    			    
    		    }
    	    });
    }
    
}


@SuppressWarnings("serial")
class Button extends JFrame
{
	private JPanel buttonPanel;
	private getData d=new getData();
	public Button()
	{
	    JButton myButton=new JButton("成绩单");
	    JButton orderButton=new JButton("排序并计算平均分和GPA");
	    buttonPanel=new JPanel();
	    buttonPanel.add(myButton);
	    buttonPanel.add(orderButton);
	    add(buttonPanel);
	    
	    Action action1=new Action(1);
	    Action action2=new Action(2);
	    myButton.addActionListener(action1);
	    orderButton.addActionListener(action2);
	    
	}
    private class Action implements ActionListener
    {
    	private int act;
    	public Action(int i)
    	{
    	   act=i;
    	}
    	public void actionPerformed(ActionEvent event)
    	{
    		if(act==1)
    		{    			
    		    buttonPanel.setBackground(Color.yellow);
    		    System.out.println("1");
    		    try {			    	
			    	d.getDataFromHTMLToexcle();
				
			    } catch (Exception e) {
			    	// TODO Auto-generated catch block
			    	e.printStackTrace();
			    }
    	    }
    		else if(act==2)
    		{
    			System.out.println("2");
    			buttonPanel.setBackground(Color.blue);
    			try {
					d.orderDataStoreToExcle();
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    	}
    }   
}
