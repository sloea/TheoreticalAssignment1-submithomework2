package myGrades;

public class classes implements Comparable<classes>{

	private String id;
	private String name;
	private String couseType;
	private String value;
	private String teacher;
	private String college;
	private String learnType;
	private String year;
	private String term;
	private String score="0";
	private static double sumValue;
	private static double sumScore;
	private static double sumGPA;
	public String[] data=new String[10];
	public classes()
	{
		
	}
	public classes(String aid,String aname,String acouseType,String avalue,String ateacher ,String acollege,String alearnType,String ayear,String aterm,String ascore)
	{
		id=data[0]=aid;
		name=data[1]=aname;
		couseType=data[2]=acouseType;
		value=data[3]=avalue;
		year=data[4]=ayear;
		teacher=data[5]=ateacher;
		term=data[6]=aterm;
		if(!ascore.equals(""))
		score=data[7]=ascore;
		else score=data[7]="0";
		college=data[8]=acollege;
		learnType=data[9]=alearnType;
		if(this.getScore()>0)
		sumValue=sumValue+this.getValue();
		sumScore=sumScore+this.getValue()*this.getScore();		
		sumGPA=sumGPA+this.setGPA();
	}
	public String getId()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
	public String getType()
	{
		return couseType;
	}
	public double getValue()
	{
		return Double.parseDouble(value);
	}
	public String getTeacher()
	{
		return teacher;
	}
	public String getYear()
	{
		return year;
	}
	public String getTerm()
	{
		return term;
	}
	public double getScore()
	{		
		if (Double.parseDouble(score)!=0)
		return Double.parseDouble(score);
		else return 0;
	}
	public String getAverageScore()
	{
		return String.valueOf(sumScore/sumValue);
	}
	private double setGPA()
	{
		
			if (this.getScore() >= 90.0)
            {
                return 4.0*this.getValue();
            }
            else if (this.getScore()>= 85.0)
            {
                return 3.7*this.getValue();
            }
            else if (this.getScore()>= 82.0)
            {
               return 3.3*this.getValue();
            }
            else if (this.getScore()>= 78.0)
            {
                return 3.0*this.getValue();
            }
            else if (this.getScore()>= 75.0)
            {
                return 2.7*this.getValue();
            }
            else if (this.getScore()>= 72.0)
            {
                return 2.3*this.getValue();
            }
            else if (this.getScore()>= 68.0)
            {
                return 2.0*this.getValue();
            }
            else if (this.getScore()>= 64.0)
            {
                return 1.5*this.getValue();
            }
            else if (this.getScore()>= 60.0)
            {
                return 1.0*this.getValue();
            }
            else return 0;
	}
	public String getGPA()
	{
		return String.valueOf(sumGPA/sumValue);
	}
	public int compareTo(classes other)
	{
		return Double.compare(other.getScore(),this.getScore());
	}
	public String toString()
	{
		return id+name+couseType+value+teacher+college+learnType+year+term+score;
	}
}
