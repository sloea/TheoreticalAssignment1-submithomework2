package myGrades;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import java.io.File;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import java.io.FileOutputStream;
import java.util.*;
public class getData {
private classes[] sub=new classes[39];
public getData()
{
	
}
public void getDataFromHTMLToexcle() throws Exception
{
	  
	  File file= new File("MyScore.html");
	  Document doc= Jsoup.parse(file,"GB2312");
	  Element table= doc.select("table[class=table listTable]").first();
      //parse subjects and store them into a excel
	  WritableWorkbook workbook = Workbook.createWorkbook(new FileOutputStream("score.xls"));
      WritableSheet sheet = workbook.createSheet("SHEET", 0);
      Iterator<Element> subjectIte = table.select("td").iterator();
      int i = 0;
      while (subjectIte.hasNext())
      {
    	 String[] datas=new String[10];
    	 for(int j=0;j<10;j++)
    	 {
    		 datas[j]=subjectIte.next().text();
    		 Label label = new Label(j, i, datas[j]);
             sheet.addCell(label);
    	 }
          sub[i] = new classes(datas[0],datas[1],datas[2],datas[3],datas[4],datas[5],datas[6],datas[7],datas[8],datas[9]);
          subjectIte.next();   
          i++;
      }
      workbook.write();
      workbook.close();
      
}
public void orderDataStoreToExcle() throws Exception
{
	if(sub[0]!=null)
	{
	WritableWorkbook workbook = Workbook.createWorkbook(new FileOutputStream("final.xls"));
    WritableSheet sheet = workbook.createSheet("SHEET", 0);
	Arrays.sort(sub);
	int i=0;
      for (classes c:sub)
      {
    	  for(int j=0;j<10;j++)
    	  {
    	  Label label = new Label(j, i,c.data[j]);
          sheet.addCell(label);
    	  }
    	  System.out.println(c);
    	  i++;
      }
      classes c=new classes();
      Label labelaverage1=new Label(0,i,"加权平均");
      sheet.addCell(labelaverage1);
      Label labelaverage2=new Label(1,i,c.getAverageScore());
      sheet.addCell(labelaverage2);
      i++;
      Label labelGPA1=new Label(0,i,"GPA");
      sheet.addCell(labelGPA1);
      Label labelGPA2=new Label(1,i,c.getGPA());
      sheet.addCell(labelGPA2);
      workbook.write();
      workbook.close();
	}
}
public classes getSub(int n)
{
	return sub[n-1];
}
}