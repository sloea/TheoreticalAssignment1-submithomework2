package ��ҵ2��;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.io.FileOutputStream;
import java.io.PrintStream;
public class Readtxt 
    {
public static void main(String[]args) throws IOException
    {
	int[] ary={96,80,87	,89	,72	,74	,82	,89	,89	,69	,73	,72	,74	,90	,69	,46	,84	,90	,82	,75	,67	,61	,74};
	ary=selectionSort(ary);
	System.out.println("�ɼ�����:");
	System.out.println(Arrays.toString(ary));
	System.out.println("��Ȩƽ����:");
	double a;
	a=(96*1.5+80*1+87*2+89*0.5+72*1+74*0.5+82*2+89*1+89*3+69*5+73*2+72*3+74*2+90*2+69*2+46*3+84*0.5+90*2+82*3+75*5+67*3+61*3+74*3)/
	  (1.5+1+2+0.5+1+0.5+2+1+3+5+2+3+2+2+2+3+0.5+2+3+5+3+3+3);
	System.out.println(a);
	System.out.println("��ȨGPA:");
	double b;
	b=(4*1.5+3*1+3.7*2+3.7*0.5+1*2.3+0.5*2.3+2*3.3+3.7*1+3.7*3+2.0*5+2.3*2+2.3*3+2.3*2+4*2+2.0*2+0+3.3*0.5+4*2+3.3*3+2.7*5+1.5*3+1*3+2.3*3)/
	  (1.5+1+2+0.5+1+0.5+2+1+3+5+2+3+2+2+2+0.5+2+3+5+3+3+3);
	System.out.println(b);
	File file = new File("C:\\Users\\zhujiatong123\\workspace\\��ҵ2��\\src\\��ҵ2��\\������1.txt");
	BufferedReader reader=null;
	String tempString=null;
	int line=1;
	try 
	{
	System.out.println("�γ��б�:");
	reader = new BufferedReader(new FileReader(file));
	while ((tempString = reader.readLine()) != null) 
	{
	System.out.println("Line"+ line + ":" +tempString);
	line ++ ;
	}
	reader.close();
    } 
	catch (FileNotFoundException e) 
	{
    // TODO Auto-generated catch block
	e.printStackTrace();
	} 
	catch (IOException e) 
	{
    // TODO Auto-generated catch block
	e.printStackTrace();
    }
	finally
	{
	if(reader != null)
	{
	try 
	{
    reader.close();
	} 
	catch (IOException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
    }
    }
	FileOutputStream fs = new FileOutputStream(new File("D:\\text.txt"));
	PrintStream p = new PrintStream(fs);
	p.println("�ɼ�����:");
	p.println(Arrays.toString(ary));
	p.println("��Ȩƽ����:");
	p.println(a);
	p.println("��ȨGPA:");
	p.println(b);
	p.close();
	}

public static int[] selectionSort(int[] ary) 
    {
	// TODO Auto-generated method stub
	for(int i=0;i<ary.length-1;i++)
	{
	for(int j=i+1;j<ary.length;j++)
	{
	if(ary[i]<ary[j])
	{
	int temp=ary[j];
	ary[j]=ary[i];
	ary[i]=temp;
	}
	}
	}
	return ary;
    }
    }
