package first;

import java.io.File;

public class Heavyslafeng {
	public static void main(String[] args) {
		MainOutPut m1 = new MainOutPut();
		File input =  new File("��ҫ�ͳɼ�.xls");
		try {
			m1.processScoreTable(input);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
