package com.image;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;

import javax.swing.*;




public class MainGUI extends JFrame{
	JButton button0 = new JButton("Calculate");
	JButton button1 = new JButton("Output");
	JButton[]buttons = {button0,button1};
	public MainGUI(){
		JFrame jf = new JFrame("Scores Processor");
		final JTextArea jt = new JTextArea();
		Container c = jf.getContentPane();
		jf.setResizable(false);
		
		ImageIcon a = new ImageIcon("img/1.jpg");
		button0.setIcon(a);
		ImageIcon b = new ImageIcon("img/2.jpg");
		button1.setIcon(b);
		
		JPanel pane1 = new JPanel();
		JPanel pane2 = new JPanel();
		
		pane1.add(jt);
		pane2.setLayout(new GridLayout(1, 2, 10, 10));
		for (int i = 0; i < buttons.length; i++) {
			pane2.add(buttons[i]);
		}
		c.add(pane1, BorderLayout.NORTH);
		c.add(pane2, BorderLayout.CENTER);
		c.setBackground(getBackground());
		OutputStream textAreaStream = new OutputStream() {
			public void write(int b) throws IOException {
				jt.append(String.valueOf((char)b));
			}
			public void write(byte b[]) throws IOException {
				jt.append(new String(b));
			}
			public void write(byte b[], int off, int len) throws IOException {
				jt.append(new String(b, off, len));
			}
		}; 	
		PrintStream myOut = new PrintStream(textAreaStream);
		System.setOut(myOut);
		System.setErr(myOut);
		button0.addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent e) {
				Transcript transcript = new Transcript();
				transcript.readExcelFile("Transcript.xls");
				System.out.println("WeightedAverage:" + transcript.weightedAverage);
				System.out.println("GPA:" + transcript.GPA);
			}
		});
		button1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent e) {
				Transcript transcript = new Transcript();
				transcript.MainOutPut("Transcript.xls");
				System.out.println("�ɼ����Ѿ������ˣ��������Լ����ļ�");
			}
		});
		
		jf.setVisible(true);
		jf.setSize(400,300);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		new MainGUI();
	}
}
