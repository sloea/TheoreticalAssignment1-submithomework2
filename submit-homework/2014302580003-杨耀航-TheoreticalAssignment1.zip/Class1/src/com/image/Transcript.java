package com.image;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


public class Transcript{
	int rsColumns;//sheet���е�������
	int rsRows;//sheet���е�������
	int counter = 0;//���з�����Ŀ��������
	public double GPA = 0.0;
	public double weightedAverage = 0.0;
	double []creditsOfScores = new double[40];
	Subject [] subject = new Subject[40];
	jxl.Workbook read = null;
	public Transcript(){
		for(int i = 0;i < 40;i++){
			subject[i] = new Subject();
		}
	}
	public void readExcelFile(String path){
		try{
			InputStream input = new FileInputStream(path);//�ӱ��ش���Workbook
			read = Workbook.getWorkbook(input);
			Sheet readSheet = read.getSheet(0);//sheet���±��Ǵ�0��ʼ�ģ�������һ��sheet��
			rsColumns = readSheet.getColumns();//��ȡsheet���е�������
			rsRows = readSheet.getRows();//��ȡsheet���е�������
			for(int i = 2;i < rsRows;i++){//һ�����ǿ��кͱ���ͷ
				for(int j = 0;j < rsColumns;j++){
					Cell cell = readSheet.getCell(j, i);
					
					switch(j){
					case 0:
						subject[i-2].s_number = Long.parseLong(cell.getContents());
						break;
					case 1:
						subject[i-2].s_name = cell.getContents();
						break;
					case 2:
						subject[i-2].s_type = cell.getContents();
						break;
					case 3:
						subject[i-2].s_credits = Double.parseDouble(cell.getContents());
						break;
					case 4:
						subject[i-2].s_teacher = cell.getContents();
						break;
					case 5:
						subject[i-2].s_institute = cell.getContents();
						break;
					case 6:
						subject[i-2].s_type1 = cell.getContents();
						break;
					case 7:
						subject[i-2].s_year = Double.parseDouble(cell.getContents());
						break;
					case 8:
						subject[i-2].s_semester = cell.getContents();
						break;
					case 9:
						if(i < 27){
							subject[i-2].s_grade = Double.parseDouble(cell.getContents());
							counter++;
						}
						break;
					}
				}
			}
			getWeightedAverage();
			getGPA();
			Arrays.sort(subject);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void writeExcelFile(OutputStream os){
		try{
			WritableWorkbook wbook= Workbook.createWorkbook(os); //����excel�ļ� 
			WritableSheet wsheet = wbook.createSheet("Transcript", 0); //���������� 
			//����Excel���� 
			WritableFont wfont = new WritableFont(WritableFont.ARIAL, 10, 
			WritableFont.BOLD, false, 
			jxl.format.UnderlineStyle.NO_UNDERLINE, 
			jxl.format.Colour.BLACK); 
			WritableCellFormat titleFormat = new WritableCellFormat(wfont); 
			
			//����Excel��ͷ 
			String[] title = {"��ͷ��","�γ�����","�γ�����",	"ѧ��","��ʦ","�ڿ�ѧԺ","ѧϰ����","ѧ��","ѧ��","�ɼ�"}; 
			for (int i = 0; i < title.length; i++) { 
			Label excelTitle = new Label(i, 0, title[i], titleFormat); 
			wsheet.addCell(excelTitle); 
			}
			
			for(int i = 1;i < 40;i++){
				for(int j = 0;j < 10;j++){
					switch(j){
					case 0:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_number));
						break;
					case 1:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_name));
						break;
					case 2:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_type));
						break;
					case 3:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_credits));
						break;
					case 4:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_teacher));
						break;
					case 5:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_institute));
						break;
					case 6:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_type1));
						break;
					case 7:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_year));
						break;
					case 8:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_semester));
						break;
					case 9:
						wsheet.addCell(new Label(j,i,"" + subject[i-1].s_grade));
						break;
					}
				}
			}
			wsheet.addCell(new Label(1,40,"WeightedAverage"));
			wsheet.addCell(new Label(1,41,"GPA"));
			wsheet.addCell(new Label(3,40,weightedAverage + ""));
			wsheet.addCell(new Label(3,41,GPA + ""));
			wbook.write(); //д���ļ� 
			wbook.close(); 
			os.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void getWeightedAverage(){
		
		double sum = 0.0;//���Ʒ���*ѧ���ܺ�
		double sumOfCredits = 0.0;//ѧ��֮��
		for(int i = 0;i < counter;i++){
			sum += subject[i].s_grade * subject[i].s_credits;
			sumOfCredits += subject[i].s_credits; 
		}
		weightedAverage = sum / sumOfCredits;
	}
	public void getGPA(){
		double sum = 0.0;//���Ƽ���*ѧ���ܺ�
		double sumOfCredits = 0.0;//ѧ��֮��
		
		for(int i = 0;i < counter;i++){//����������ζ�Ӧ��ѧ��
			if(subject[i].s_grade<60.0) creditsOfScores[i] = 0.0;
			else if(subject[i].s_grade < 64.0) creditsOfScores[i] = 1.0;
			else if(subject[i].s_grade < 68.0) creditsOfScores[i] = 1.5;
			else if(subject[i].s_grade < 72.0) creditsOfScores[i] = 2.0;
			else if(subject[i].s_grade < 75.0) creditsOfScores[i] = 2.3;
			else if(subject[i].s_grade < 78.0) creditsOfScores[i] = 2.7;
			else if(subject[i].s_grade < 82.0) creditsOfScores[i] = 3.0;
			else if(subject[i].s_grade < 85.0) creditsOfScores[i] = 3.3;
			else if(subject[i].s_grade < 90.0) creditsOfScores[i] = 3.7;
			else  creditsOfScores[i] = 4.0;
		}
		for(int i = 0;i < counter;i++){
			sum += subject[i].s_credits * creditsOfScores[i];
			sumOfCredits += subject[i].s_credits; 
		}
		GPA = sum / sumOfCredits;
	}
	public void MainOutPut(String path){
		readExcelFile(path);
		File f=new File("Transcript1.xls"); 
	    try { 
	    	f.createNewFile(); 
	    	writeExcelFile(new FileOutputStream(f)); 
	    } catch (IOException e) { 
	    	e.printStackTrace(); 
	    } 
	}
}