package com.image;

class Subject implements Comparable<Subject>{
	long s_number;//�γ̺�
	String s_name;//�γ�����
	String s_type;//�γ�����
	double s_credits;//ѧ��
	String s_teacher;//��ʦ
	String s_institute;//�ڿ�ѧԺ
	String s_type1;//ѧϰ����
	double s_year;//ѧ��
	String s_semester;//ѧ��
	double s_grade;//�ɼ�
	@Override
	public int compareTo(Subject subject) {//����ѧ�ֺͷ�������
		// TODO Auto-generated method stub
		if(this.s_grade > subject.s_grade){
			return -1;
		}else if(this.s_grade<subject.s_grade){
			return 1;
		}else{
			if(this.s_credits>subject.s_credits){
				return 1;
			}else if(this.s_credits<subject.s_credits){
				return -1;
			}else{
				return 0;
			}
		}
	}	
	public Subject(
		long s_number,
		String s_name,
		String s_type,
		double s_credits,
		String s_teacher,
		String s_institute,
		String s_type1,
		double s_year,
		String s_semester,
		double s_grade){
			this.s_number = s_number;
			this.s_name = s_name;
			this.s_type = s_type;
			this.s_credits = s_credits;
			this.s_teacher = s_teacher;
			this.s_institute = s_institute;
			this.s_type1 = s_type1;
			this.s_year = s_year;
			this.s_semester = s_semester;
			this.s_grade = s_grade; 
		}
		public Subject() {
		// TODO Auto-generated constructor stub
		}
		public String toString(){
			return s_number+"\t"+s_name+"\t"+s_type+"\t"+s_credits+"\t"+s_teacher
			+"\t"+s_institute+"\t"+s_type1+"\t"+s_year+"\t"+s_semester+"\t"+s_grade;
		}
}	