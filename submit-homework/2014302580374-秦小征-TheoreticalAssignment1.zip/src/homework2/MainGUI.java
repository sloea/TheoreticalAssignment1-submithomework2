package homework2;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.HttpRequest;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;

public class MainGUI {
	private static JFrame frame;
	private static JButton btn;
	private static JButton btna;
	private static int courseNum;
	private static int process;
	
	public static void main(String[] args) {
		// ������Ч�γ���
		courseNum = 21;
		frame = new JFrame("gui");
		btn = new JButton("��ȡ�ɼ�");
		btna = new JButton("�ɼ�����");
		btn.setBackground(Color.cyan);
		btn.addActionListener(new ActionListener(){
	    	   public void actionPerformed(ActionEvent e){
	    		   btnAction();
	    	   }
	       });
		btna.setBackground(Color.green);
		btna.addActionListener(new ActionListener(){
	    	   public void actionPerformed(ActionEvent e){
	    		   try {
					btnaAction();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
	    	   }
	       });
		frame.setLayout(new GridLayout(5,2,20,20));
		frame.add(btn);
		frame.add(btna);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 300);
		frame.setLocation(500, 200);
		System.out.printf("main:end");
	}
	
	
	
	private static void btnAction(){
		// ��ע����� url �� Cookie
		String url = "http://210.42.121.134/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sat%20Oct%2010%202015%2019:25:38%20GMT+0800";
		 String fName = "./main.html";
		 HttpRequest response = HttpRequest.get(url);
		 response.header("Cookie", "JSESSIONID=0C696879CB8E817AD3DE241024634F65.tomcat2");
		 response.receive(new File(fName));
			File input = new File("./main.html");
			String btnText = "��ȡ�ɼ�������ɣ�"; 
			if(input.exists())
				;
			else 
				btnText = "��ȡ�ɼ�ʱ����";
		 btn.setText(btnText);
	}
	
	private static void btnaAction() throws IOException{
		// ��Ȩƽ��ֵ ; gpa
		double jiaQuan = 0;
		double gpa = 0;
		double allXueFen = 0;
		
		File input = new File("./main.html");
		String btnaText = "����������output.xls�ļ�"; 
		if(input.exists())
			;
		else 
			btnaText = "��ȡ�ɼ�ʱ����";
		// ���html�ĵ�, ��jsoup����
		Document doc = Jsoup.parse(file2String(input));
		// �������tr
		Elements trs = doc.getElementsByTag("tr");
		int i = 0;
		int a;
		double xueFen = 0;
		Elements tds;
		//���� xls �ļ�
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet st = wb.createSheet();
		HSSFRow row;
		HSSFCell cell;
		for (Element tr : trs) {
			if(i >= courseNum + 1) // �޶��γ�����
				break;
			if(i == 0){ // ����������һ��
				i++;
				row = st.createRow(0);
				tds = tr.getElementsByTag("th"); // careful: th 
				a = 0;
				for(Element td : tds){
					if(a >= 10) //11��֮�����Ϣ����
						break;
					System.out.printf("%s\t", td.html());
					cell = row.createCell(a);
					cell.setCellValue(td.html());
					a++;
				}
				continue;
			}
			row = st.createRow(i);
			tds = tr.getElementsByTag("td");
			a = 0;
			for(Element td : tds){
				if(a == 3){
					xueFen = Double.parseDouble(td.html().trim());
					allXueFen += xueFen;
				}
				if(a == 9){
					gpa += getGpa(Double.parseDouble(td.html().trim())) * xueFen;
					jiaQuan += Double.parseDouble(td.html().trim()) * xueFen;
				}
				if(a >= 10) //11��֮�����Ϣ����
					break;
				System.out.printf("%s\t", td.html());
				cell = row.createCell(a);
				cell.setCellValue(td.html());
				a++;
			}
			System.out.printf("\n");
			i++;
		}
		// ����
		int j;
		showSt(st);
	    for (i = 1; i <= courseNum ; i++) {
	        for ( j = i + 1; j <= courseNum; j++) {
	        	System.out.printf("%d, ", j);
	            if (Double.parseDouble(st.getRow(i).getCell(9).getStringCellValue().trim()) < Double.parseDouble(st.getRow(j).getCell(9).getStringCellValue().trim())) {
	                exchangeRow(st.getRow(j), st.getRow(i));
	                System.out.printf("process%d\n", process);
	              //  showSt(st);
	            }
	        }
	    }
		// �����Ȩƽ���֣�gpa��д��
		gpa = gpa / allXueFen;
		jiaQuan = jiaQuan / allXueFen;
		row = st.createRow(courseNum + 1);
		cell = row.createCell(0);
		cell.setCellValue("��Ȩƽ����");
		cell = row.createCell(1);
		cell.setCellValue(jiaQuan);
		row = st.createRow(courseNum + 2);
		cell = row.createCell(0);
		cell.setCellValue("GPA");
		cell = row.createCell(1);
		cell.setCellValue(gpa);
		// д���ļ�
		FileOutputStream outFile = new FileOutputStream("./output.xls");
		wb.write(outFile);
		outFile.close();
		wb.close();
		btna.setBackground(Color.orange);
		btna.setText(btnaText);
	}
	
	// tool function 
	public static String file2String(File file) throws IOException{
		InputStream is = new FileInputStream(file);
		BufferedReader in = new BufferedReader(new InputStreamReader(is));
		StringBuffer buffer = new StringBuffer();
		String line = "";
		while((line = in.readLine()) != null){
			buffer.append(line);
		}
		in.close();
		return buffer.toString();
	}
	// ����һ��
	public static void exchangeRow(HSSFRow row, HSSFRow row2){
		HSSFWorkbook wb=new HSSFWorkbook();
		HSSFSheet st = wb.createSheet();
		HSSFRow tem= st.createRow(0);
		int index;
		if(row.getLastCellNum() > row2.getLastCellNum()){
			index = row.getLastCellNum() - 1;
		}else index = row2.getLastCellNum() - 1;
		for(; index > -1; index--){
			tem.createCell(index);
		}
		//HSSFRow tem = null;
		int a;
		// copy row to tem
		for(a = 0; a < row.getLastCellNum(); a++){
			if (row.getCell(a).getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
				tem.getCell(a).setCellValue(row.getCell(a).getNumericCellValue());
			} else if (row.getCell(a).getCellType() == HSSFCell.CELL_TYPE_STRING) {
				tem.getCell(a).setCellValue(row.getCell(a).getStringCellValue());
			} else {
				System.out.println("error:exchangeRow()");
			}
		}
		// copy row2 to row
		for(a = 0; a < row2.getLastCellNum(); a++){
			if (row2.getCell(a).getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
				row.getCell(a).setCellValue(row2.getCell(a).getNumericCellValue());
			} else if (row2.getCell(a).getCellType() == HSSFCell.CELL_TYPE_STRING) {
				row.getCell(a).setCellValue(row2.getCell(a).getStringCellValue());
			} else {
				System.out.println("error:exchangeRow()");
			}
		}
		// copy tem to row2
		for(a = 0; a < tem.getLastCellNum(); a++){
			if (tem.getCell(a).getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
				row2.getCell(a).setCellValue(tem.getCell(a).getNumericCellValue());
			} else if (tem.getCell(a).getCellType() == HSSFCell.CELL_TYPE_STRING) {
				row2.getCell(a).setCellValue(tem.getCell(a).getStringCellValue());
			} else {
				System.out.println("error:exchanegRow()");
			}
		}
	}
	// ����gpa�ֶ� 
	public static double getGpa(double score){
		double back;
		if(score >= 90)
		{
			back = 4.0;
		}
		else if(score >= 85
				&&score < 90)
		{
			back = 3.7;
		}
		else if(score >= 82
				&& score < 85)
		{
			back = 3.3;
		}
		else if(score >= 78
				&& score < 82)
		{
			back = 3.0;
		}
		else if(score >= 75
				&& score < 78)
		{
			back = 2.7;
		}
		else if(score >= 72
				&& score < 75)
		{
			back = 2.3;
		}
		else if(score >= 68
				&& score < 72)
		{
			back = 2.0;
		}
		else if(score >= 64
				&& score < 68)
		{
			back = 1.5;
		}
		else if(score >= 60
				&& score < 64)
		{
			back = 1.0;
		}
		else
		{
			back = 0.0;
		}
		return back;
	}
	// ����ʱʹ�õĺ���    ��ӡ��sheet
	private static void showSt(HSSFSheet st){
		System.out.printf("from showSt ------------------------------------\n");
		int i,j;
		for(i = 1; i <= courseNum; i++){
			for(j = 0; j < 10; j++){
				System.out.printf("%s\t", st.getRow(i).getCell(j).getStringCellValue());
			}
			System.out.printf("\n");
		}
		System.out.printf("end of showSt ------------------------------------\n");
	}
}
/*
import javax.swing.*;

import java.awt.*;

public class Homework2 {
	private JFrame frame = new JFrame("��½����");
	private JPanel imagePanel;
	private ImageIcon background;
	private JButton jb1,jb2;
	private JLabel jl1,jl2,jl3,jl4;
	private JComboBox<String> jcb;
	private JTextField jtf1,jtf2;
	private JPanel jp;
	public static void main(String[] args) {
		new Homework2();
	}

	public Homework2() {
		
		
		
		background = new ImageIcon("50.png");// ����ͼƬ
		JLabel label = new JLabel(background);// �ѱ���ͼƬ��ʾ��һ����ǩ����
		// �ѱ�ǩ�Ĵ�Сλ������ΪͼƬ�պ�����������
		label.setBounds(0, 0, background.getIconWidth(),
				background.getIconHeight());
		// �����ݴ���ת��ΪJPanel���������÷���setOpaque������ʹ���ݴ���͸��
		imagePanel = (JPanel) frame.getContentPane();
		imagePanel.setOpaque(false);
		// ���ݴ���Ĭ�ϵĲ��ֹ�����ΪBorderLayout
		jl1 = new JLabel("�û�ID",JLabel.RIGHT);
		jl2 = new JLabel("��  ��",JLabel.RIGHT);
	//	jl3 = new JLabel("�û����",JLabel.RIGHT);
		jl4 = new JLabel();
		jb1 = new JButton("��½");
		jb2 =  new JButton("ȡ��");
		jtf1 = new JTextField(10);
		jtf2 = new JTextField(10);
	//	String[] ss = {"�������Ա","ϵͳ����Ա","ѧ��"};
		jp = new JPanel(new GridLayout(3, 3,20,10));
	//	jcb = new JComboBox<String>(ss);
		imagePanel.setLayout(new BorderLayout());
		jp.add(jl1);jp.add(jtf1);jp.add(jb1);
		jp.add(jl2);jp.add(jtf2);jp.add(jb2);
	//	jp.add(jl3);jp.add(jcb);jp.add(jl4);
	//	jp.setOpaque(false);
		imagePanel.add(jp,BorderLayout.NORTH);
		
		//ntegerָ��������ÿ���������ȣ����б�Žϸߵ����λ���������֮�ϡ�
		frame.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(background.getIconWidth(), background.getIconHeight());
		frame.setVisible(true);
	}
}
*/